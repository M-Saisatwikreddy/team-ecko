import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const map: Record<string, string> = {
  Active: "bg-success/15 text-success border-success/30",
  Available: "bg-info/15 text-info border-info/30",
  Maintenance: "bg-warning/15 text-warning border-warning/40",
  Offline: "bg-muted text-muted-foreground border-border",
  "On Duty": "bg-success/15 text-success border-success/30",
  "Off Duty": "bg-muted text-muted-foreground border-border",
  "On Leave": "bg-warning/15 text-warning border-warning/40",
  "In Transit": "bg-primary/15 text-primary border-primary/30",
  Scheduled: "bg-info/15 text-info border-info/30",
  Completed: "bg-success/15 text-success border-success/30",
  Delayed: "bg-destructive/15 text-destructive border-destructive/30",
  "In Progress": "bg-primary/15 text-primary border-primary/30",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <Badge variant="outline" className={cn("font-medium", map[status] ?? "")}>
      <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current" />
      {status}
    </Badge>
  );
}
