export const kpis = {
  activeVehicles: 148,
  availableVehicles: 92,
  maintenanceVehicles: 14,
  activeTrips: 63,
  driversOnDuty: 78,
  fleetUtilization: 82,
  fuelCost: 48210,
  maintenanceCost: 12840,
};

export const utilizationTrend = [
  { day: "Mon", utilization: 74, trips: 48 },
  { day: "Tue", utilization: 78, trips: 52 },
  { day: "Wed", utilization: 82, trips: 61 },
  { day: "Thu", utilization: 79, trips: 55 },
  { day: "Fri", utilization: 88, trips: 68 },
  { day: "Sat", utilization: 71, trips: 44 },
  { day: "Sun", utilization: 66, trips: 39 },
];

export const fuelTrend = [
  { month: "Jan", fuel: 32400, maintenance: 9800 },
  { month: "Feb", fuel: 34100, maintenance: 10200 },
  { month: "Mar", fuel: 36700, maintenance: 11500 },
  { month: "Apr", fuel: 39200, maintenance: 10800 },
  { month: "May", fuel: 42100, maintenance: 12100 },
  { month: "Jun", fuel: 45600, maintenance: 11900 },
  { month: "Jul", fuel: 48210, maintenance: 12840 },
];

export const fleetBreakdown = [
  { name: "Trucks", value: 62, color: "var(--chart-1)" },
  { name: "Vans", value: 41, color: "var(--chart-2)" },
  { name: "Sedans", value: 28, color: "var(--chart-3)" },
  { name: "Buses", value: 17, color: "var(--chart-4)" },
];

export type Vehicle = {
  id: string;
  plate: string;
  type: string;
  model: string;
  status: "Active" | "Available" | "Maintenance" | "Offline";
  driver: string;
  fuel: number;
  mileage: number;
};

export const vehicles: Vehicle[] = [
  { id: "V-1042", plate: "MH12-AB-4521", type: "Truck", model: "Volvo FH 460", status: "Active", driver: "R. Mehta", fuel: 78, mileage: 128400 },
  { id: "V-1043", plate: "DL08-CX-9088", type: "Van", model: "Ford Transit", status: "Available", driver: "—", fuel: 92, mileage: 45210 },
  { id: "V-1044", plate: "KA05-QR-7712", type: "Sedan", model: "Toyota Camry", status: "Active", driver: "S. Iyer", fuel: 54, mileage: 68900 },
  { id: "V-1045", plate: "TN22-JD-3390", type: "Bus", model: "Mercedes Tourismo", status: "Maintenance", driver: "—", fuel: 21, mileage: 214300 },
  { id: "V-1046", plate: "GJ01-KL-2201", type: "Truck", model: "Tata Prima", status: "Active", driver: "A. Khan", fuel: 66, mileage: 92100 },
  { id: "V-1047", plate: "UP16-MN-6612", type: "Van", model: "Mercedes Sprinter", status: "Offline", driver: "—", fuel: 12, mileage: 156700 },
  { id: "V-1048", plate: "RJ14-PQ-8845", type: "Truck", model: "Scania R500", status: "Available", driver: "—", fuel: 88, mileage: 34220 },
  { id: "V-1049", plate: "HR26-ST-1129", type: "Sedan", model: "Honda City", status: "Active", driver: "P. Nair", fuel: 43, mileage: 79800 },
];

export type Driver = {
  id: string;
  name: string;
  license: string;
  phone: string;
  status: "On Duty" | "Off Duty" | "On Leave";
  rating: number;
  trips: number;
  vehicle: string;
};

export const drivers: Driver[] = [
  { id: "D-201", name: "Rohan Mehta", license: "MH-2024-4451", phone: "+91 98211 22114", status: "On Duty", rating: 4.9, trips: 342, vehicle: "V-1042" },
  { id: "D-202", name: "Sunita Iyer", license: "KA-2023-8890", phone: "+91 99801 55442", status: "On Duty", rating: 4.8, trips: 289, vehicle: "V-1044" },
  { id: "D-203", name: "Amir Khan", license: "GJ-2022-3312", phone: "+91 90099 77841", status: "On Duty", rating: 4.7, trips: 401, vehicle: "V-1046" },
  { id: "D-204", name: "Priya Nair", license: "HR-2024-9021", phone: "+91 98110 44238", status: "On Duty", rating: 4.9, trips: 218, vehicle: "V-1049" },
  { id: "D-205", name: "Vikram Singh", license: "DL-2021-1108", phone: "+91 98999 32210", status: "Off Duty", rating: 4.5, trips: 512, vehicle: "—" },
  { id: "D-206", name: "Neha Kapoor", license: "MH-2023-7712", phone: "+91 99202 45119", status: "On Leave", rating: 4.6, trips: 176, vehicle: "—" },
];

export type Trip = {
  id: string;
  vehicle: string;
  driver: string;
  origin: string;
  destination: string;
  status: "In Transit" | "Scheduled" | "Completed" | "Delayed";
  distance: number;
  eta: string;
};

export const trips: Trip[] = [
  { id: "T-9821", vehicle: "V-1042", driver: "R. Mehta", origin: "Mumbai", destination: "Pune", status: "In Transit", distance: 148, eta: "2h 10m" },
  { id: "T-9822", vehicle: "V-1044", driver: "S. Iyer", origin: "Bangalore", destination: "Chennai", status: "In Transit", distance: 346, eta: "5h 45m" },
  { id: "T-9823", vehicle: "V-1046", driver: "A. Khan", origin: "Ahmedabad", destination: "Surat", status: "Delayed", distance: 265, eta: "1h 20m late" },
  { id: "T-9824", vehicle: "V-1049", driver: "P. Nair", origin: "Delhi", destination: "Gurgaon", status: "Completed", distance: 32, eta: "Arrived" },
  { id: "T-9825", vehicle: "V-1043", driver: "V. Singh", origin: "Hyderabad", destination: "Vijayawada", status: "Scheduled", distance: 275, eta: "Tomorrow 06:00" },
  { id: "T-9826", vehicle: "V-1048", driver: "R. Kumar", origin: "Kolkata", destination: "Bhubaneswar", status: "Scheduled", distance: 442, eta: "Tomorrow 08:30" },
];

export type MaintenanceRecord = {
  id: string;
  vehicle: string;
  type: string;
  status: "Scheduled" | "In Progress" | "Completed";
  date: string;
  cost: number;
  workshop: string;
};

export const maintenance: MaintenanceRecord[] = [
  { id: "M-501", vehicle: "V-1045", type: "Engine overhaul", status: "In Progress", date: "2026-07-10", cost: 4200, workshop: "TransitCare Chennai" },
  { id: "M-502", vehicle: "V-1047", type: "Transmission", status: "Scheduled", date: "2026-07-14", cost: 2800, workshop: "AutoWorks Lucknow" },
  { id: "M-503", vehicle: "V-1042", type: "Tire replacement", status: "Completed", date: "2026-07-02", cost: 1200, workshop: "FleetHub Mumbai" },
  { id: "M-504", vehicle: "V-1046", type: "Brake service", status: "Scheduled", date: "2026-07-16", cost: 780, workshop: "TransitCare Ahmedabad" },
  { id: "M-505", vehicle: "V-1049", type: "AC service", status: "Completed", date: "2026-06-28", cost: 340, workshop: "AutoWorks Gurgaon" },
];

export type Expense = {
  id: string;
  vehicle: string;
  type: "Fuel" | "Toll" | "Parking" | "Repair";
  liters: number;
  amount: number;
  date: string;
  location: string;
};

export const expenses: Expense[] = [
  { id: "E-8801", vehicle: "V-1042", type: "Fuel", liters: 220, amount: 21450, date: "2026-07-11", location: "IOC Panvel" },
  { id: "E-8802", vehicle: "V-1044", type: "Fuel", liters: 68, amount: 6820, date: "2026-07-11", location: "HP Hosur Rd" },
  { id: "E-8803", vehicle: "V-1046", type: "Toll", liters: 0, amount: 840, date: "2026-07-10", location: "NH-48" },
  { id: "E-8804", vehicle: "V-1049", type: "Fuel", liters: 42, amount: 4210, date: "2026-07-10", location: "Shell DLF" },
  { id: "E-8805", vehicle: "V-1048", type: "Repair", liters: 0, amount: 3200, date: "2026-07-09", location: "FleetHub Jaipur" },
  { id: "E-8806", vehicle: "V-1043", type: "Parking", liters: 0, amount: 220, date: "2026-07-09", location: "IGI T3" },
];
