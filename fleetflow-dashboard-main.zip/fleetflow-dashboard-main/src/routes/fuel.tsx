import { createFileRoute } from "@tanstack/react-router";
import { DollarSign, Fuel, Plus, Receipt } from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell } from "@/components/app/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { expenses, fuelTrend } from "@/lib/mock-data";

export const Route = createFileRoute("/fuel")({
  head: () => ({
    meta: [
      { title: "Fuel & Expenses · TransitOps AI" },
      { name: "description", content: "Log fuel refills, tolls, parking and repair expenses across the fleet." },
    ],
  }),
  component: FuelPage,
});

function FuelPage() {
  return (
    <AppShell
      title="Fuel & Expenses"
      subtitle="Consumption, cost and expense tracking"
      actions={
        <Button style={{ background: "var(--gradient-primary)" }} className="text-white">
          <Plus className="mr-2 h-4 w-4" /> Log expense
        </Button>
      }
    >
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { l: "Fuel spend (MTD)", v: "$48.2K", i: Fuel, t: "text-primary bg-primary/10" },
          { l: "Avg. cost / km", v: "$0.32", i: DollarSign, t: "text-info bg-info/10" },
          { l: "Total expenses", v: "$61.0K", i: Receipt, t: "text-warning bg-warning/10" },
          { l: "Savings vs LM", v: "+4.2%", i: DollarSign, t: "text-success bg-success/10" },
        ].map((s) => (
          <Card key={s.l}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className={"grid h-10 w-10 place-items-center rounded-lg " + s.t}>
                  <s.i className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{s.l}</p>
                  <p className="text-xl font-bold tabular-nums">{s.v}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Fuel spend trend</CardTitle>
          <CardDescription>Monthly consumption cost</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={fuelTrend} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="fg" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Area type="monotone" dataKey="fuel" stroke="var(--primary)" strokeWidth={2} fill="url(#fg)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Recent expenses</CardTitle>
          <CardDescription>All logged expenses in the last 7 days</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Liters</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expenses.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell className="font-medium">{e.id}</TableCell>
                    <TableCell className="font-mono text-xs">{e.vehicle}</TableCell>
                    <TableCell><Badge variant="outline">{e.type}</Badge></TableCell>
                    <TableCell className="text-muted-foreground">{e.location}</TableCell>
                    <TableCell className="text-muted-foreground">{e.date}</TableCell>
                    <TableCell className="text-right tabular-nums">{e.liters || "—"}</TableCell>
                    <TableCell className="text-right font-semibold tabular-nums">${e.amount.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </AppShell>
  );
}
