import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings · TransitOps AI" },
      { name: "description", content: "Manage your workspace, team, notifications and integrations." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <AppShell title="Settings" subtitle="Workspace, team, and preferences">
      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-6 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Organization</CardTitle>
              <CardDescription>Basic workspace information.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5"><Label>Company name</Label><Input defaultValue="TransitOps Logistics Pvt Ltd" /></div>
                <div className="space-y-1.5"><Label>Fleet size</Label><Input defaultValue="254" /></div>
                <div className="space-y-1.5"><Label>Time zone</Label>
                  <Select defaultValue="ist"><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ist">Asia/Kolkata (IST)</SelectItem>
                      <SelectItem value="utc">UTC</SelectItem>
                      <SelectItem value="est">America/New_York (EST)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5"><Label>Currency</Label>
                  <Select defaultValue="usd"><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="usd">USD ($)</SelectItem>
                      <SelectItem value="inr">INR (₹)</SelectItem>
                      <SelectItem value="eur">EUR (€)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Separator />
              <div className="flex justify-end gap-2">
                <Button variant="outline">Cancel</Button>
                <Button style={{ background: "var(--gradient-primary)" }} className="text-white">Save changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Choose what alerts you receive.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { l: "Trip delays", d: "Get notified when a trip is running behind schedule.", def: true },
                { l: "Low fuel alerts", d: "Alerts when vehicle fuel drops below 20%.", def: true },
                { l: "Maintenance due", d: "Reminders for upcoming scheduled service.", def: true },
                { l: "Weekly digest", d: "Summary email every Monday morning.", def: false },
              ].map((n) => (
                <div key={n.l} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="min-w-0"><p className="font-medium">{n.l}</p><p className="text-xs text-muted-foreground">{n.d}</p></div>
                  <Switch defaultChecked={n.def} />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Integrations</CardTitle>
              <CardDescription>Connect TransitOps to your tools.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2">
              {["Slack", "Google Maps", "SAP", "Twilio SMS", "Stripe", "QuickBooks"].map((i) => (
                <div key={i} className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <p className="font-medium">{i}</p>
                    <p className="text-xs text-muted-foreground">Not connected</p>
                  </div>
                  <Button variant="outline" size="sm">Connect</Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Billing</CardTitle>
              <CardDescription>Current plan and usage.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border p-6" style={{ background: "var(--gradient-subtle)" }}>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Current plan</p>
                <p className="mt-1 text-2xl font-bold">Enterprise · $2,400/mo</p>
                <p className="mt-1 text-sm text-muted-foreground">Unlimited vehicles, priority support, custom SLAs.</p>
                <div className="mt-4 flex gap-2">
                  <Button style={{ background: "var(--gradient-primary)" }} className="text-white">Manage plan</Button>
                  <Button variant="outline">Download invoice</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}
