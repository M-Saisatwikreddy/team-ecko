import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Zap, Loader2, ArrowRight, ShieldCheck, Truck, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in · TransitOps AI" },
      { name: "description", content: "Sign in to your TransitOps AI fleet command center." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("ava@transitops.ai");
  const [pw, setPw] = useState("demo1234");
  const [loading, setLoading] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      toast.success("Welcome back, Ava");
      navigate({ to: "/" });
    }, 700);
  };

  return (
    <div className="grid min-h-screen grid-cols-1 lg:grid-cols-2">
      {/* Brand panel */}
      <div
        className="relative hidden overflow-hidden p-10 text-white lg:flex lg:flex-col lg:justify-between"
        style={{ background: "var(--gradient-primary)" }}
      >
        <div className="pointer-events-none absolute inset-0 opacity-40" style={{ background: "var(--gradient-hero)" }} />
        <div className="relative flex items-center gap-2 text-lg font-semibold">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-white/15 backdrop-blur">
            <Zap className="h-5 w-5" />
          </div>
          TransitOps AI
        </div>

        <div className="relative max-w-md">
          <h2 className="text-4xl font-bold leading-tight">
            Command your fleet with clarity.
          </h2>
          <p className="mt-4 text-white/85">
            Live vehicle telemetry, driver rosters, trip dispatch, maintenance
            scheduling and fuel intelligence — unified in one operations console.
          </p>
          <div className="mt-8 space-y-3 text-sm">
            {[
              { icon: Truck, label: "Track 10,000+ vehicles in real time" },
              { icon: Activity, label: "Predictive maintenance & fuel analytics" },
              { icon: ShieldCheck, label: "SOC 2 · GDPR · ISO 27001 compliant" },
            ].map((f) => (
              <div key={f.label} className="flex items-center gap-3">
                <div className="grid h-8 w-8 place-items-center rounded-md bg-white/15">
                  <f.icon className="h-4 w-4" />
                </div>
                <span>{f.label}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="relative text-xs text-white/70">© 2026 TransitOps AI · Fleet operations, reimagined.</p>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <Card className="w-full max-w-md border-0 bg-transparent p-0 shadow-none">
          <div className="mb-8 flex items-center gap-2 lg:hidden">
            <div className="grid h-9 w-9 place-items-center rounded-lg text-primary-foreground" style={{ background: "var(--gradient-primary)" }}>
              <Zap className="h-5 w-5" />
            </div>
            <span className="text-lg font-semibold">TransitOps AI</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Welcome back</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Sign in to your fleet command center.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Work email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="pw">Password</Label>
                <button type="button" className="text-xs font-medium text-primary hover:underline">
                  Forgot?
                </button>
              </div>
              <Input id="pw" type="password" value={pw} onChange={(e) => setPw(e.target.value)} required />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full text-white"
              style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-elegant)" }}
            >
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Sign in
              {!loading && <ArrowRight className="ml-2 h-4 w-4" />}
            </Button>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">or</span>
              </div>
            </div>

            <Button type="button" variant="outline" className="w-full">
              Continue with SSO
            </Button>

            <p className="text-center text-xs text-muted-foreground">
              Don't have an account? <a className="font-medium text-primary hover:underline" href="#">Request a demo</a>
            </p>
          </form>
        </Card>
      </div>
    </div>
  );
}
