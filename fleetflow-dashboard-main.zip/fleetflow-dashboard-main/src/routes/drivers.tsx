import { createFileRoute } from "@tanstack/react-router";
import { Phone, Plus, Star, UserPlus } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { StatusBadge } from "@/components/app/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { drivers } from "@/lib/mock-data";

export const Route = createFileRoute("/drivers")({
  head: () => ({
    meta: [
      { title: "Drivers · TransitOps AI" },
      { name: "description", content: "Manage driver rosters, licenses, ratings and duty status." },
    ],
  }),
  component: DriversPage,
});

function DriversPage() {
  const initials = (n: string) => n.split(" ").map((p) => p[0]).slice(0, 2).join("");
  return (
    <AppShell
      title="Driver Management"
      subtitle="104 registered drivers · 78 on duty"
      actions={
        <Button style={{ background: "var(--gradient-primary)" }} className="text-white">
          <UserPlus className="mr-2 h-4 w-4" /> Add driver
        </Button>
      }
    >
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {drivers.slice(0, 3).map((d) => (
          <Card key={d.id} className="overflow-hidden">
            <div className="h-20" style={{ background: "var(--gradient-primary)" }} />
            <CardContent className="-mt-10 space-y-3">
              <Avatar className="h-16 w-16 border-4 border-card">
                <AvatarFallback className="bg-accent text-accent-foreground text-lg font-semibold">
                  {initials(d.name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h3 className="truncate font-semibold">{d.name}</h3>
                  <StatusBadge status={d.status} />
                </div>
                <p className="text-xs text-muted-foreground">License · {d.license}</p>
              </div>
              <div className="grid grid-cols-3 gap-2 border-t pt-3 text-center text-xs">
                <div><p className="text-muted-foreground">Trips</p><p className="font-semibold tabular-nums">{d.trips}</p></div>
                <div><p className="text-muted-foreground">Rating</p>
                  <p className="flex items-center justify-center gap-1 font-semibold"><Star className="h-3 w-3 fill-warning text-warning" />{d.rating}</p>
                </div>
                <div><p className="text-muted-foreground">Vehicle</p><p className="font-semibold">{d.vehicle}</p></div>
              </div>
              <Button variant="outline" size="sm" className="w-full"><Phone className="mr-2 h-3 w-3" />Contact</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>All drivers</CardTitle>
            <CardDescription>Roster and duty assignments</CardDescription>
          </div>
          <Input placeholder="Search drivers…" className="h-9 w-56" />
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Driver</TableHead>
                  <TableHead>License</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Trips</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Vehicle</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {drivers.map((d) => (
                  <TableRow key={d.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9">
                          <AvatarFallback className="bg-accent text-accent-foreground text-xs font-semibold">{initials(d.name)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium leading-tight">{d.name}</p>
                          <p className="text-xs text-muted-foreground">{d.id}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{d.license}</TableCell>
                    <TableCell className="text-muted-foreground">{d.phone}</TableCell>
                    <TableCell><StatusBadge status={d.status} /></TableCell>
                    <TableCell className="text-right tabular-nums">{d.trips}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center gap-1 rounded-full bg-warning/10 px-2 py-0.5 text-xs font-medium text-warning">
                        <Star className="h-3 w-3 fill-current" />{d.rating}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{d.vehicle}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </AppShell>
  );
}
