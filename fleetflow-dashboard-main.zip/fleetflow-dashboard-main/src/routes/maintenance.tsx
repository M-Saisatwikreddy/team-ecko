import { createFileRoute } from "@tanstack/react-router";
import { Plus, Wrench } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { StatusBadge } from "@/components/app/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { maintenance } from "@/lib/mock-data";

export const Route = createFileRoute("/maintenance")({
  head: () => ({
    meta: [
      { title: "Maintenance · TransitOps AI" },
      { name: "description", content: "Track work orders, service history, and workshop assignments." },
    ],
  }),
  component: MaintenancePage,
});

function MaintenancePage() {
  return (
    <AppShell
      title="Maintenance"
      subtitle="12 open work orders · 3 due this week"
      actions={
        <Button style={{ background: "var(--gradient-primary)" }} className="text-white">
          <Plus className="mr-2 h-4 w-4" /> New work order
        </Button>
      }
    >
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { l: "Open", v: 12 },
          { l: "In Progress", v: 5 },
          { l: "Completed (MTD)", v: 34 },
          { l: "Cost (MTD)", v: "$12.8K" },
        ].map((s) => (
          <Card key={s.l}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-warning/10 text-warning">
                  <Wrench className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{s.l}</p>
                  <p className="text-xl font-bold tabular-nums">{s.v}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Work orders</CardTitle>
          <CardDescription>Scheduled and in-progress maintenance</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Workshop</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {maintenance.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="font-medium">{m.id}</TableCell>
                    <TableCell className="font-mono text-xs">{m.vehicle}</TableCell>
                    <TableCell>{m.type}</TableCell>
                    <TableCell className="text-muted-foreground">{m.workshop}</TableCell>
                    <TableCell className="text-muted-foreground">{m.date}</TableCell>
                    <TableCell><StatusBadge status={m.status} /></TableCell>
                    <TableCell className="text-right tabular-nums">${m.cost.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </AppShell>
  );
}
