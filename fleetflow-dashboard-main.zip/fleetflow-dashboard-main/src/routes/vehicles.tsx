import { createFileRoute } from "@tanstack/react-router";
import { Filter, Plus, Search, Truck } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { StatusBadge } from "@/components/app/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { vehicles } from "@/lib/mock-data";

export const Route = createFileRoute("/vehicles")({
  head: () => ({
    meta: [
      { title: "Vehicles · TransitOps AI" },
      { name: "description", content: "Manage your fleet vehicles — status, fuel, mileage and assignments." },
    ],
  }),
  component: VehiclesPage,
});

function VehiclesPage() {
  return (
    <AppShell
      title="Vehicle Management"
      subtitle="254 vehicles across 8 depots"
      actions={
        <Dialog>
          <DialogTrigger asChild>
            <Button style={{ background: "var(--gradient-primary)" }} className="text-white">
              <Plus className="mr-2 h-4 w-4" /> Add vehicle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Register a new vehicle</DialogTitle>
              <DialogDescription>Enter the details to onboard a vehicle to the fleet.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>License plate</Label><Input placeholder="MH12-AB-1234" /></div>
                <div className="space-y-1.5"><Label>Type</Label>
                  <Select><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="truck">Truck</SelectItem>
                      <SelectItem value="van">Van</SelectItem>
                      <SelectItem value="sedan">Sedan</SelectItem>
                      <SelectItem value="bus">Bus</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5"><Label>Model</Label><Input placeholder="Volvo FH 460" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Depot</Label><Input placeholder="Mumbai" /></div>
                <div className="space-y-1.5"><Label>Odometer (km)</Label><Input type="number" placeholder="0" /></div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">Cancel</Button>
              <Button style={{ background: "var(--gradient-primary)" }} className="text-white">Save vehicle</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Total", value: 254 },
          { label: "Active", value: 148 },
          { label: "Available", value: 92 },
          { label: "Maintenance", value: 14 },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                  <Truck className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                  <p className="text-xl font-bold tabular-nums">{s.value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle>All vehicles</CardTitle>
            <CardDescription>Live fleet roster</CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search plate, model…" className="h-9 w-48 pl-8 sm:w-64" />
            </div>
            <Button variant="outline" size="sm"><Filter className="mr-1.5 h-4 w-4" /> Filter</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="border-b px-6 pb-3">
            <Tabs defaultValue="all">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="active">Active</TabsTrigger>
                <TabsTrigger value="available">Available</TabsTrigger>
                <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>License Plate</TableHead>
                  <TableHead>Type / Model</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead>Fuel</TableHead>
                  <TableHead className="text-right">Mileage</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {vehicles.map((v) => (
                  <TableRow key={v.id}>
                    <TableCell className="font-medium">{v.id}</TableCell>
                    <TableCell>{v.plate}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-medium">{v.model}</span>
                        <span className="text-xs text-muted-foreground">{v.type}</span>
                      </div>
                    </TableCell>
                    <TableCell><StatusBadge status={v.status} /></TableCell>
                    <TableCell className="text-muted-foreground">{v.driver}</TableCell>
                    <TableCell>
                      <div className="flex w-32 items-center gap-2">
                        <Progress value={v.fuel} className="h-1.5" />
                        <span className="w-9 text-right text-xs tabular-nums">{v.fuel}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{v.mileage.toLocaleString()} km</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </AppShell>
  );
}
