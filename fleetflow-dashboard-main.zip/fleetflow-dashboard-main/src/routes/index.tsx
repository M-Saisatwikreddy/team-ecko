import { createFileRoute } from "@tanstack/react-router";
import {
  Activity,
  CircleDollarSign,
  Fuel,
  Gauge,
  Route as RouteIcon,
  Truck,
  UserCheck,
  Wrench,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/app/app-shell";
import { KpiCard } from "@/components/app/kpi-card";
import { StatusBadge } from "@/components/app/status-badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  fleetBreakdown,
  fuelTrend,
  kpis,
  trips,
  utilizationTrend,
  vehicles,
} from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard · TransitOps AI" },
      {
        name: "description",
        content:
          "Live overview of fleet utilization, active trips, drivers on duty, fuel and maintenance costs.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  return (
    <AppShell
      title="Fleet Overview"
      subtitle="Real-time snapshot of operations · Updated just now"
      actions={
        <Button className="hidden sm:inline-flex" style={{ background: "var(--gradient-primary)" }}>
          + New Trip
        </Button>
      }
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Active Vehicles" value={String(kpis.activeVehicles)} hint="of 254 total" icon={Truck} accent="primary" delta={4.2} />
        <KpiCard label="Available Vehicles" value={String(kpis.availableVehicles)} hint="ready to dispatch" icon={Activity} accent="info" delta={2.1} />
        <KpiCard label="In Maintenance" value={String(kpis.maintenanceVehicles)} hint="3 due this week" icon={Wrench} accent="warning" delta={-1.4} />
        <KpiCard label="Active Trips" value={String(kpis.activeTrips)} hint="12 arriving < 1h" icon={RouteIcon} accent="primary" delta={8.9} />
        <KpiCard label="Drivers On Duty" value={String(kpis.driversOnDuty)} hint="of 104 registered" icon={UserCheck} accent="success" delta={3.5} />
        <KpiCard label="Fleet Utilization" value={`${kpis.fleetUtilization}%`} hint="target 85%" icon={Gauge} accent="info" delta={1.8} />
        <KpiCard label="Fuel Cost (MTD)" value={`$${(kpis.fuelCost / 1000).toFixed(1)}K`} hint="vs $45.6K last month" icon={Fuel} accent="warning" delta={5.7} />
        <KpiCard label="Maintenance Cost" value={`$${(kpis.maintenanceCost / 1000).toFixed(1)}K`} hint="12 open work orders" icon={CircleDollarSign} accent="destructive" delta={-2.3} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0">
            <div>
              <CardTitle>Utilization & Trips</CardTitle>
              <CardDescription>Last 7 days</CardDescription>
            </div>
            <div className="hidden gap-4 text-xs text-muted-foreground sm:flex">
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" /> Utilization</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-chart-2" /> Trips</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={utilizationTrend} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="ug" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="tg" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-2)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--chart-2)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                      color: "var(--popover-foreground)",
                    }}
                  />
                  <Area type="monotone" dataKey="utilization" stroke="var(--primary)" strokeWidth={2} fill="url(#ug)" />
                  <Area type="monotone" dataKey="trips" stroke="var(--chart-2)" strokeWidth={2} fill="url(#tg)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fleet Composition</CardTitle>
            <CardDescription>By vehicle type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={fleetBreakdown} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>
                    {fleetBreakdown.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Legend verticalAlign="bottom" iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Fuel vs Maintenance Cost</CardTitle>
            <CardDescription>Monthly, in USD</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={fuelTrend} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                    }}
                  />
                  <Bar dataKey="fuel" fill="var(--primary)" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="maintenance" fill="var(--chart-4)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fleet Health</CardTitle>
            <CardDescription>Key operational indicators</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {[
              { label: "On-time delivery", value: 94 },
              { label: "Vehicle uptime", value: 87 },
              { label: "Driver compliance", value: 96 },
              { label: "Fuel efficiency", value: 78 },
            ].map((row) => (
              <div key={row.label}>
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{row.label}</span>
                  <span className="font-semibold tabular-nums">{row.value}%</span>
                </div>
                <Progress value={row.value} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>Active & Recent Trips</CardTitle>
            <CardDescription>Live view of dispatches</CardDescription>
          </div>
          <Button variant="outline" size="sm">View all</Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Trip</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead className="text-right">Distance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>ETA</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trips.slice(0, 5).map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium">{t.id}</TableCell>
                    <TableCell className="text-muted-foreground">{t.vehicle}</TableCell>
                    <TableCell>{t.driver}</TableCell>
                    <TableCell className="text-muted-foreground">{t.origin} → {t.destination}</TableCell>
                    <TableCell className="text-right tabular-nums">{t.distance} km</TableCell>
                    <TableCell><StatusBadge status={t.status} /></TableCell>
                    <TableCell className="text-muted-foreground">{t.eta}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Vehicles requiring attention</CardTitle>
          <CardDescription>Low fuel, high mileage, or overdue service</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {vehicles.filter((v) => v.fuel < 50 || v.status !== "Active").slice(0, 6).map((v) => (
            <div key={v.id} className="rounded-lg border bg-card p-4 transition hover:shadow-md">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate font-semibold">{v.model}</p>
                  <p className="truncate text-xs text-muted-foreground">{v.plate} · {v.type}</p>
                </div>
                <StatusBadge status={v.status} />
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Fuel</p>
                  <div className="mt-1 flex items-center gap-2">
                    <Progress value={v.fuel} className="h-1.5" />
                    <span className="tabular-nums">{v.fuel}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground">Mileage</p>
                  <p className="mt-1 font-medium tabular-nums">{v.mileage.toLocaleString()} km</p>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </AppShell>
  );
}
