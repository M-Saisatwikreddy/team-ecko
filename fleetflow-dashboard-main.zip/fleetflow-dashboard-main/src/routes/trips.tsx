import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, MapPin, Plus } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { StatusBadge } from "@/components/app/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trips } from "@/lib/mock-data";

export const Route = createFileRoute("/trips")({
  head: () => ({
    meta: [
      { title: "Trips · TransitOps AI" },
      { name: "description", content: "Dispatch, monitor and manage trips across your fleet." },
    ],
  }),
  component: TripsPage,
});

function TripsPage() {
  return (
    <AppShell
      title="Trip Management"
      subtitle="63 active · 18 scheduled today"
      actions={
        <Button style={{ background: "var(--gradient-primary)" }} className="text-white">
          <Plus className="mr-2 h-4 w-4" /> New trip
        </Button>
      }
    >
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: "In Transit", value: 41, tone: "text-primary bg-primary/10" },
          { label: "Scheduled", value: 18, tone: "text-info bg-info/10" },
          { label: "Delayed", value: 4, tone: "text-destructive bg-destructive/10" },
          { label: "Completed today", value: 92, tone: "text-success bg-success/10" },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className={"inline-flex rounded-md px-2 py-0.5 text-xs font-medium " + s.tone}>{s.label}</div>
              <p className="mt-3 text-2xl font-bold tabular-nums">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle>All trips</CardTitle>
            <CardDescription>Realtime status of dispatches</CardDescription>
          </div>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="live">Live</TabsTrigger>
              <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Trip ID</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead className="text-right">Distance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>ETA</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trips.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium">{t.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                        <span>{t.origin}</span>
                        <ArrowRight className="h-3 w-3 text-muted-foreground" />
                        <span>{t.destination}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{t.vehicle}</TableCell>
                    <TableCell>{t.driver}</TableCell>
                    <TableCell className="text-right tabular-nums">{t.distance} km</TableCell>
                    <TableCell><StatusBadge status={t.status} /></TableCell>
                    <TableCell className="text-muted-foreground">{t.eta}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </AppShell>
  );
}
